
public class TestDriver {

	public static void main(String[] args) {

		int[] row = {4,0};   //row selection
		int[] col = {2};     //column selection




		TableMaker pivot =  new TableMaker(RawDataReader.loadRawRecords("MOCK_TXT.csv"), row, col, 1, -1, 3);   //TableMaker


		String[][][] test = pivot.getOutArray();     //return array from TableMaker

		String[] pageNames = pivot.getPageNames();  //return of page titles (only call if pages are selected)
		
		int page = 0;   //index for page title

		
		
		//for loops for displaying output
		
		for(String[][] x : test){
			
			for(String[] y : x){
				
				for(String z : y){
					System.out.print(z + " ");
				}
				
				System.out.println();
				
			}
		
			System.out.println("********************************************************************************************************************************* Page: "+ pageNames[page]);
			page++;
		}

		
		
	}
}
